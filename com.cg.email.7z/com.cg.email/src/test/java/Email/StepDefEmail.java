package Email;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.EmailRegistrationPageFactory;

public class StepDefEmail {

	private WebDriver driver;
	private EmailRegistrationPageFactory objhbpf;

@Given("^User is on booking page$")
public void user_is_on_booking_page() throws Throwable {
	driver = new FirefoxDriver();
	 Thread.sleep(1000);
	   objhbpf = new EmailRegistrationPageFactory(driver);
	   driver.get("file:///D:/Lesson%205-HTML%20Pages/WorkingWithForms.html");
	  
}

@Then("^check the heading of page$")
public void check_the_heading_of_page() throws Throwable {
	 String title = driver.getTitle();
	    if(title.equals("Email Registration Forms")) {
	    	System.out.println("Title Correct");
	    }else {
	    	System.out.println("Title Wrong!");
	    }
	   
}

@When("^User clicks on confirm booking button$")
public void user_clicks_on_confirm_booking_button() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("Male");
	objhbpf.setPfemail("rnagdev@gmail.com");
	objhbpf.setPfaddress("PVR");
	objhbpf.setPfcity("Mumbai");
	objhbpf.setPfphone("9922974725");
	objhbpf.setPfhobby("Movies");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();

}


@When("^User does not enter username$")
public void user_does_not_enter_username() throws Throwable {
	objhbpf.setPfuserName("");
	   Thread.sleep(1000);
	   objhbpf.setPfconfirm();

}
@Then("^display alert msg$")
public void display_alert_msg() throws Throwable {
	String str=driver.switchTo().alert().getText();
	System.out.println(str);
    Thread.sleep(1000);
    driver.switchTo().alert().accept();
    Thread.sleep(1000);
    driver.close();
  }

@When("^User does not enter password$")
public void user_does_not_enter_password() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	   Thread.sleep(1000);
	   objhbpf.setPfpassword("");
	   Thread.sleep(1000);
	   objhbpf.setPfconfirm();
}

@When("^User does not enter same password and confirm passwords$")
public void user_does_not_enter_same_password_and_confirm_passwords() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	   objhbpf.setPfpassword("capgemini");
	   objhbpf.setPfconfpassword("capg");
	objhbpf.setPfconfirm();
	String str=driver.switchTo().alert().getText();
	System.out.println(str);
	driver.switchTo().alert().accept();
    	       
}

@When("^User does not enter firstname , lastname$")
public void user_does_not_enter_firstname_lastname() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("");
	objhbpf.setPflastName("");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();

  }
@When("^User does not select gender$")
public void user_does_not_select_gender() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();

}

@When("^User does not enter email in correct format$")
public void user_does_not_enter_email_in_correct_format() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("Male");
	objhbpf.setPfemail("");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();

}
@When("^User does not address$")
public void user_does_not_address() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("Male");
	objhbpf.setPfemail("rnagdev@gmail.com");
	objhbpf.setPfaddress("");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();
  }
@When("^User does not select city$")
public void user_does_not_select_city() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("Male");
	objhbpf.setPfemail("rnagdev@gmail.com");
	objhbpf.setPfaddress("PVR");
	objhbpf.setPfcity("Mumbai");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();}

@When("^User does not enter mobile number$")
public void user_does_not_enter_mobile_number() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("Male");
	objhbpf.setPfemail("rnagdev@gmail.com");
	objhbpf.setPfaddress("PVR");
	objhbpf.setPfcity("Mumbai");
	objhbpf.setPfphone("");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();  

}

@When("^User enters incorrect mobileNo format and clicks the button$")
public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("Male");
	objhbpf.setPfemail("rnagdev@gmail.com");
	objhbpf.setPfaddress("PVR");
	objhbpf.setPfcity("Mumbai");
	 List<String> objlist=arg1.asList(String.class);
	    
	    for(int i=0; i<objlist.size(); i++) {
	    	objhbpf.getPfphone().clear();
	    	objhbpf.setPfphone(objlist.get(i));
	    	objhbpf.setPfconfirm();
	        
	    	Thread.sleep(1000);
	    	driver.switchTo().alert();
	        Thread.sleep(1000);
	        driver.switchTo().alert().accept();
	        
	    	if(Pattern.matches("[7-9]{1}[0-9]{9}$", objlist.get(i))) {
	    		System.out.println("********Matched" +objlist.get(i) + "*******");
	    	}
	    	else {

	    		System.out.println("********Not Matched" +objlist.get(i) + "*******");
	    	}
	    }
	    objhbpf.setPfconfirm();
	    	
	 }



@When("^User does not select hobbies$")
public void user_does_not_select_Facilities() throws Throwable {
	objhbpf.setPfuserName("rnagdev");
	objhbpf.setPfpassword("capg");
	objhbpf.setPfconfpassword("capg");
	objhbpf.setPffirstName("Rahul");
	objhbpf.setPflastName("Nagdev");
	objhbpf.setPfgender("Male");
	objhbpf.setPfemail("rnagdev@gmail.com");
	objhbpf.setPfaddress("PVR");
	objhbpf.setPfcity("Mumbai");
	objhbpf.setPfphone("9922974725");
	objhbpf.setPfhobby("Movies");
	Thread.sleep(1000);
	objhbpf.setPfconfirm();  

}

}
