package Email;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumEmail {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
  }

  @Test
  public void testSeleniumEmail() throws Exception {
    driver.get("file:///D:/Lesson%205-HTML%20Pages/WorkingWithForms.html");
    driver.findElement(By.id("txtUserName")).clear();
    driver.findElement(By.id("txtUserName")).sendKeys("rnagdev");
    driver.findElement(By.id("txtPassword")).clear();
    driver.findElement(By.id("txtPassword")).sendKeys("capg");
    driver.findElement(By.id("txtConfPassword")).clear();
    driver.findElement(By.id("txtConfPassword")).sendKeys("capg");
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Please enter your first name", closeAlertAndGetItsText());
    driver.findElement(By.id("txtFirstName")).clear();
    driver.findElement(By.id("txtFirstName")).sendKeys("Rahul");
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Please enter your last name", closeAlertAndGetItsText());
    driver.findElement(By.id("txtLastName")).clear();
    driver.findElement(By.id("txtLastName")).sendKeys("Nagdev");
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Please select your gender", closeAlertAndGetItsText());
    driver.findElement(By.id("rbMale")).click();
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Please enter valid email", closeAlertAndGetItsText());
    driver.findElement(By.id("txtEmail")).clear();
    driver.findElement(By.id("txtEmail")).sendKeys("rnagdev@gmail.com");
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Please enter address", closeAlertAndGetItsText());
    driver.findElement(By.id("txtAddress")).clear();
    driver.findElement(By.id("txtAddress")).sendKeys("PVR");
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Please select city", closeAlertAndGetItsText());
    new Select(driver.findElement(By.name("City"))).selectByVisibleText("Mumbai");
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Please enter valid mobile number", closeAlertAndGetItsText());
    driver.findElement(By.id("txtPhone")).clear();
    driver.findElement(By.id("txtPhone")).sendKeys("9922974725");
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Plase select any one hobby", closeAlertAndGetItsText());
    driver.findElement(By.id("Music")).click();
    driver.findElement(By.cssSelector("input.submit")).click();
    assertEquals("Validation completed", closeAlertAndGetItsText());
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
