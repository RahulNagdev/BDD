package pageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EmailRegistrationPageFactory {
	WebDriver driver;
	
	@FindBy(id="txtUserName")
	WebElement pfuserName;
	
	@FindBy(id="txtPassword")
	WebElement pfpassword;
	@FindBy(id="txtConfPassword")
	WebElement pfconfpassword;
	
	@FindBy(id="txtFirstName")
	WebElement pffirstName;
	
	@FindBy(id="txtLastName")
	WebElement pflastName;
	
	@FindBy(name="gender")
	WebElement pfgender;
	
	@FindBy(id="txtEmail")
	WebElement pfemail;
	
	@FindBy(id="txtAddress")
	WebElement pfaddress;
	
	@FindBy(name="City")
	WebElement pfcity;

	@FindBy(id="txtPhone")
	WebElement pfphone;

	@FindBy(name="chkHobbies")
	WebElement pfhobby;
	
	@FindBy(className="submit")
	WebElement pfconfirm;

	@FindBy(className="reset")
	WebElement pfreset;

	public EmailRegistrationPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		}

	public WebElement getPfuserName() {
		return pfuserName;
	}

	public void setPfuserName(String userName) {
		pfuserName.sendKeys(userName);;
	}

	public WebElement getPfpassword() {
		return pfpassword;
	}

	public void setPfpassword(String password) {
		pfpassword.sendKeys(password);
	}

	public WebElement getPfconfpassword() {
		return pfconfpassword;
	}

	public void setPfconfpassword(String confpassword) {
		pfconfpassword.sendKeys(confpassword);
	}

	public WebElement getPffirstName() {
		return pffirstName;
	}

	public void setPffirstName(String firstName) {
		pffirstName.sendKeys(firstName);
	}

	public WebElement getPflastName() {
		return pflastName;
	}

	public void setPflastName(String lastName) {
		pflastName.sendKeys(lastName);
	}

	public WebElement getPfgender() {
		return pfgender;
	}

	public void setPfgender(String gender) {
		if(gender.equals("Male"))
		{
			pfgender.findElement(By.xpath("//*[@id='rbMale']")).click();
			
		}
		else if(gender.equals("Female"))
		{
			pfgender.findElement(By.xpath("//*[@id='rbFemale']")).click();
			
		}
		}
		
	public WebElement getPfemail() {
		return pfemail;
	}

	public void setPfemail(String email) {
		pfemail.sendKeys(email);
	}

	public WebElement getPfaddress() {
		return pfaddress;
	}

	public void setPfaddress(String address) {
		pfaddress.sendKeys(address);
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public void setPfcity(String city) {
		Select sel = new Select(pfcity);
		sel.selectByVisibleText(city);
	}

	public WebElement getPfphone() {
		return pfphone;
	}

	public void setPfphone(String phone) {
		pfphone.sendKeys(phone);
	}

	public WebElement getPfhobby() {
		return pfhobby;
	}

	public void setPfhobby(String hobby) {
		if(hobby.equals("Music"))
		{
			pfhobby.findElement(By.xpath("//*[//*[@id='Music']]")).click();
			
		}
		else if(hobby.equals("Reading"))
		{
			pfhobby.findElement(By.xpath("//*[@id='Reading']")).click();
			
		}
		else if(hobby.equals("Movies"))
		{
			pfhobby.findElement(By.xpath("//*[@id='Movies']")).click();
			
		}
	}


	public WebElement getPfconfirm() {
		return pfconfirm;
	}

	public void setPfconfirm() {
		pfconfirm.click();
		}
	public WebElement getPfreset() {
		return pfreset;
	}

	public void setPfreset() {
		pfreset.click();
		}
		
	
	
}
